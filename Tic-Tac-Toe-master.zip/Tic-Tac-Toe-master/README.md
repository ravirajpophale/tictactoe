# Tic Tac Toe
Tic-tac-toe is a paper-and-pencil game for two players, X and O, who take turns marking the spaces in a 3×3 grid. The player who succeeds in placing three of their marks in a horizontal, vertical, or diagonal row wins the game. 
To add this project to android studio.

#### Features
- Single Player with Difficulty levels 
- Two Player

#### Getting started
- In android studio goto file 
- Select new > Import from version control 
- Choose git / github (git option recommanded ) 
- Paste url to repository i.e https://github.com/karansthr/Tic-Tac-Toe.git
- Click on clone.

Play Store https://play.google.com/store/apps/details?id=jetray.tictactoe

[![N|Solid](https://lh3.googleusercontent.com/qwq46W93q9KXYGofoK1fOB4D6LfZ7DRZWbveSvO4Z9Kadcl5ZjP7WQBGZ4gHQ6FdmNY=h900-rw)]

[![N|Solid](https://lh3.googleusercontent.com/xNiyu77Vk7Ma9LxMxh7xh8vs8iMXXNgxTxs8mtKR_JAzsaswdseeJR1YJ354Kc-r=h900-rw)]

[![N|Solid](https://lh3.googleusercontent.com/kdI4CNLqG2K9-CIpSFrfZt0sfdLfyV2veprdwM5c2r6qoQX4GJCou_cIwcfOFHfqP7E=h900-rw)]

